﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
    Actividad 3: Elección de Paquete de Viaje

    Problema:
    Una agencia de viajes ofrece distintos tipos de paquetes turísticos.
    
    Requisitos:
        ● Usar tres RadioButton para seleccionar el destino principal: &quot;Playa&quot;, &quot;Montaña&quot; o
        &quot;Ciudad&quot;.

        ● Agregar un ComboBox para elegir la duración del viaje (ejemplo: &quot;3 días&quot;, &quot;7 días&quot;,
        &quot;15 días&quot;).

        ● Un botón &quot;Confirmar&quot; debe mostrar en un Label la opción seleccionada.
*/

namespace Punto3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label1.Text = $"Destino: {radioButton1.Text}  |  ";
            }

            if (radioButton2.Checked == true)
            {
                label1.Text = $"Destino: {radioButton2.Text}  |  ";
            }

            if (radioButton3.Checked == true)
            {
                label1.Text = $"Destino: {radioButton3.Text}  |  ";
            }

            label1.Text += $"Duracion: {comboBox1.Text}";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
