﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
    Actividad 1: Registro de Usuario Simple

    Problema:
    Se desea crear un formulario para registrar usuarios en un sistema.

    Requisitos:
        ● Mostrar etiquetas (Label) para "Nombre", "Apellido" y "Correo".

        ● Permitir que el usuario escriba los datos en TextBox.

        ● Incluir un botón "Registrar" que, al presionarlo, muestra en un Label un mensaje con
        los datos ingresados concatenados.
*/

namespace Punto1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = $"Nombre: {textBox1.Text}  |  Apellido: {textBox2.Text}  |  Correo: {textBox3.Text}";
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
