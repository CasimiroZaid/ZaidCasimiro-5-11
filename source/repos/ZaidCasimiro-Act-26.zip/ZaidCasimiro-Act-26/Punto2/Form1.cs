﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
    2.  Permitir el ingreso de dos números en controles de tipo TextBox y mediante
        dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
        restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
        operación.
*/

namespace Punto2
{
    public partial class Form1 : Form
    {
        double resultado = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBox1.Text);
            double num2 = double.Parse(textBox2.Text);

            resultado = num1 += num2;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            double num1 = double.Parse(textBox1.Text);
            double num2 = double.Parse(textBox2.Text);

            resultado = num1 -= num2;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Text = $"{resultado}";
        }
    }
}
