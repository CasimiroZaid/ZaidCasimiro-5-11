﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
    3.  Solicitar el ingreso del nombre de una persona y seleccionar de un control
        ComboBox un país. Al presionar un botón mostrar en la barra del título del
        Form el nombre ingresado y el país seleccionado.
*/

namespace Punto3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Text = textBox1.Text;
            Text += $" {comboBox1.Text}";
        }
    }
}
